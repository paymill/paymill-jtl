<?php
define('MODULE_PAYMENT_PAYMILL_ACCEPTED_CARDS', 'Akzeptierte Kreditkarten');
define('MODULE_PAYMENT_PAYMILL_TEXT_TITLE', 'Kreditkarte');
define('MODULE_PAYMENT_PAYMILL_STATUS_TITLE', 'Kreditkartenmodul aktivieren');
define('MODULE_PAYMENT_PAYMILL_STATUS_DESC', '');
define('MODULE_PAYMENT_PAYMILL_SORT_ORDER_TITLE', 'Anzeigereihenfolge');
define('MODULE_PAYMENT_PAYMILL_SORT_ORDER_DESC', 'Reihenfolge der Anzeige. Kleinste Ziffer wird zuerst angezeigt.');
define('MODULE_PAYMENT_PAYMILL_PRIVATEKEY_TITLE', 'Geheimer API Key');
define('MODULE_PAYMENT_PAYMILL_PRIVATEKEY_DESC', '');
define('MODULE_PAYMENT_PAYMILL_PUBLICKEY_TITLE', '&Ouml;ffentlicher API Key');
define('MODULE_PAYMENT_PAYMILL_PUBLICKEY_DESC', '');
define('MODULE_PAYMENT_PAYMILL_TEXT_ERROR_100', 'Zahlung konnte nicht ausgef&uuml;hrt werden. Der Zahlungsstatus ist "open"');
define('MODULE_PAYMENT_PAYMILL_TEXT_ERROR_200', 'Zahlung konnte nicht ausgef&uuml;hrt werden.');
define('MODULE_PAYMENT_PAYMILL_ALLOWED_TITLE', 'Erlaubt f&uuml;r Zonen');
define('MODULE_PAYMENT_PAYMILL_ALLOWED_DESC', 'F&uuml;r alle Zonen leer lassen');
define('MODULE_PAYMENT_PAYMILL_BRIDGE_URL_TITLE', 'Bridge URL');
define('MODULE_PAYMENT_PAYMILL_BRIDGE_URL_DESC', '');
define('MODULE_PAYMENT_PAYMILL_API_URL_TITLE', 'API URL');
define('MODULE_PAYMENT_PAYMILL_API_URL_DESC', '');
//
?>